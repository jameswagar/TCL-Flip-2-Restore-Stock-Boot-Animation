# TCL Unbranded Boot Animation

This Magisk module overlays `/product/media/bootanimation.zip` with the stock animation captured read-only from a TCL 4058G (`Gflip6_NA_OM`) running build `UPEJ`.

## Source Animation

- Resolution: 240×320
- Frame rate: 30 fps
- Frames: 56 (`part0`: 31; `part1`: 25)
- Branding: TCL only; no carrier branding
- SHA-256: `dc95c9372c15785ea7bf4884a638de21b4eb62bc22457f5c7d50a5209767c025`

## Target And Rollback

Designed for the rooted TCL 4058L (`Gflip6_USCC`) on Magisk 30.7. It does not modify `/product` or the MediaTek `logo` partition. Disable or remove the module and reboot to restore the original US Cellular boot animation.

The first activation must be verified physically during reboot because ADB is unavailable during the early animation.
